from data.films import Films
from flask import Flask
from data import db_session

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/films_explorer.db")
    session = db_session.create_session()
    fm = Films()
    fm.actors = 1
    fm.film = 'Аватар'
    fm.genres = 1
    fm.directors = 1
    fm.is_published = 1
    fm.size = 162
    fm.year_of_publication = 2009
    fm.content = "Бывший морпех Джейк Салли прикован к инвалидному креслу. Несмотря на немощное тело, Джейк в душе" \
                 " по-прежнему остается воином. Он получает задание совершить путешествие в несколько световых лет к" \
                 " базе землян на планете Пандора, где корпорации добывают редкий минерал, имеющий огромное значение " \
                 "для выхода Земли из энергетического кризиса."
    fm.photo = "30.jpg"
    session.add(fm)

    fm = Films()
    fm.actors = 1
    fm.film = 'Аватар 2'
    fm.genres = 1
    fm.directors = 1
    fm.is_published = 0
    fm.size = 1
    fm.year_of_publication = 2022
    fm.content = "После принятия образа аватара солдат Джейк Салли становится предводителем народа на'ви и берет на себя" \
                 " миссию по защите новых друзей от корыстных бизнесменов с Земли. Теперь ему есть за кого бороться — с" \
                 " Джейком его прекрасная возлюбленная Нейтири. Когда на Пандору возвращаются до зубов вооруженные " \
                 "земляне, Джейк готов дать им отпор."
    fm.photo = "7.jpg"
    session.add(fm)

    session.commit()


if __name__ == '__main__':
    main()