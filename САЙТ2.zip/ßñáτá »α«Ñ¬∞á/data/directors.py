import sqlalchemy
from sqlalchemy import orm
from .db_session import SqlAlchemyBase


class Directors(SqlAlchemyBase):
    __tablename__ = 'directors'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    director = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    films = orm.relation("Films", back_populates='director')

    def __repr__(self):
        return f'<Director> {self.director}'
