import sqlalchemy
from sqlalchemy import orm

from .db_session import SqlAlchemyBase


class Films(SqlAlchemyBase):
    __tablename__ = 'films'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    actors = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("actors.id"))
    actor = orm.relation('Actors')
    film = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    genres = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("genres.id"))
    genre = orm.relation('Genres')
    my = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("users.id"))
    user = orm.relation('Users')
    directors = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("directors.id"))
    director = orm.relation('Directors')
    year_of_publication = sqlalchemy.Column(sqlalchemy.Integer, nullable=True, default=0)
    content = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    size = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)
    is_published = sqlalchemy.Column(sqlalchemy.Boolean, default=True)
    photo = sqlalchemy.Column(sqlalchemy.String, nullable=True)

    def __repr__(self):
        return f'<Film> {self.id} {self.film}'