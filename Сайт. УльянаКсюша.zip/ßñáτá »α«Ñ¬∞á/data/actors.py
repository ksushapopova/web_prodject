import sqlalchemy
from sqlalchemy import orm
from .db_session import SqlAlchemyBase


class Actors(SqlAlchemyBase):
    __tablename__ = 'actors'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    actor = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    films = orm.relation("Films", back_populates='actor')

    def __repr__(self):
        return f'{self.id} {self.surname_author} {self.name_author}'