from data.actors import Actors
from flask import Flask
from data import db_session

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/films_explorer.db")
    session = db_session.create_session()

    act = Actors()
    act.actor = 'Сэм Уортингтон'
    session.add(act)

    act = Actors()
    act.actor = 'Зои Салдана'
    session.add(act)

    session.commit()


if __name__ == '__main__':
    main()