from flask import Flask
from data import db_session
from data.users import Users

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/films_explorer.db")
    session = db_session.create_session()

    user = Users()
    user.name = "Ridley"
    user.email = "scott_chief@mars.org"
    user.hashed_password = "cap"
    user.set_password(user.hashed_password)
    session.add(user)

    user2 = Users()
    user2.name = "Adam"
    user2.email = "adamadam@mars.org"
    user2.hashed_password = "coolman"
    user2.set_password(user2.hashed_password)
    session.add(user2)

    user3 = Users()
    user3.name = "Jack"
    user3.email = "kokjack@mars.org"
    user3.hashed_password = "bestkok"
    user3.set_password(user3.hashed_password)
    session.add(user3)

    user4 = Users()
    user4.name = "Aleksandr"
    user4.email = "host_of_the_world@mars.org"
    user4.hashed_password = "amazingme"
    user4.set_password(user4.hashed_password)
    session.add(user4)

    session.commit()


if __name__ == '__main__':
    main()
